import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Activity, ShieldPlus, Drill, ScanHeart, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';

const detailedServices = [
  {
    id: "wisdom-tooth",
    icon: Sparkles,
    title: "Wisdom Tooth Extraction",
    shortDesc: "Safe and Comfortable Removal of Problematic Wisdom Teeth",
    benefits: [
      "Prevents overcrowding and shifting of other teeth",
      "Eliminates painful impaction and repeated infections",
      "Reduces risk of damage to adjacent teeth",
      "Improves overall oral hygiene access"
    ],
    procedure: "We begin with a comprehensive 3D evaluation of your jaw and the position of the wisdom teeth. Using profound local anesthesia, the tooth is gently extracted. If the tooth is impacted, a small surgical approach is used. We prioritize minimally invasive techniques to ensure rapid recovery.",
    expectations: "Most patients experience only mild discomfort for a few days, managed easily with prescribed medication. Swelling is normal and subsides quickly. You will be back to your normal routine within a week."
  },
  {
    id: "root-canal",
    icon: Activity,
    title: "Root Canal Treatment",
    shortDesc: "Save Natural Teeth While Eliminating Pain",
    benefits: [
      "Relieves severe toothache and sensitivity immediately",
      "Allows you to keep your natural tooth permanently",
      "Prevents the spread of infection to other areas",
      "Restores normal biting and chewing forces"
    ],
    procedure: "The infected or inflamed pulp inside the tooth is carefully removed using advanced rotary endodontics. The inside of the tooth is then meticulously cleaned, disinfected, and sealed with a biocompatible material to prevent future infection. Often completed in a single comfortable visit.",
    expectations: "Your tooth will no longer be sensitive to hot or cold. While it may feel slightly different for a few days, it will function just like a normal tooth once fully restored, typically with a protective crown."
  },
  {
    id: "dental-implants",
    icon: ShieldPlus,
    title: "Dental Implants",
    shortDesc: "Permanent Solutions for Missing Teeth",
    benefits: [
      "Looks, feels, and functions like a natural tooth",
      "Prevents bone loss that occurs when teeth are missing",
      "Does not require altering adjacent healthy teeth",
      "A permanent, lifetime solution with proper care"
    ],
    procedure: "A small titanium post is precisely placed into the jawbone, acting as a new tooth root. Over a healing period, the bone naturally fuses with the implant (osseointegration). Once healed, a custom-made, highly aesthetic crown is securely attached to the post.",
    expectations: "The process is surprisingly comfortable. While healing takes a few months, the final result is a rock-solid, beautiful tooth that allows you to eat any food with confidence and smile without hesitation."
  },
  {
    id: "cavity-treatment",
    icon: Drill,
    title: "Cavity Treatment & Tooth Restoration",
    shortDesc: "Protect Teeth Before Problems Become Bigger",
    benefits: [
      "Stops the progression of tooth decay instantly",
      "Restores the structural integrity of the tooth",
      "Invisible, tooth-colored materials blend seamlessly",
      "Minimally invasive, preserving maximum healthy tooth structure"
    ],
    procedure: "We use specialized tools to remove the decayed portion of the tooth painlessly. The space is then thoroughly cleaned and filled with a high-quality composite resin that matched the exact shade of your teeth. The material is hardened instantly with a special curing light.",
    expectations: "You can eat and drink normally almost immediately after the numbness wears off. The restoration is incredibly durable and designed to blend completely invisibly with your natural smile."
  },
  {
    id: "deep-cleaning",
    icon: ScanHeart,
    title: "Deep Cleaning & Gum Care",
    shortDesc: "Healthier Gums for a Stronger Smile",
    benefits: [
      "Halts the progression of gum disease (periodontitis)",
      "Eliminates chronic bad breath caused by bacteria",
      "Reduces systemic inflammation linked to heart health",
      "Tightens gums around teeth, preventing tooth mobility"
    ],
    procedure: "Also known as Scaling and Root Planing, this process involves carefully removing hardened plaque (tartar) and bacterial toxins from beneath the gum line. We then smooth the root surfaces to prevent future bacteria from attaching easily.",
    expectations: "Your gums will become firmer, pinker, and stop bleeding during brushing. With our guidance on home care and regular maintenance visits, you can maintain optimal periodontal health for life."
  }
];

export default function ServicesPage() {
  return (
    <main className="pt-32 pb-24 bg-white min-h-screen">
      {/* Header */}
      <div className="bg-slate-50 py-16 border-b border-gray-100 mb-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Our Comprehensive Services</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Explore our advanced dental treatments. We combine state-of-the-art technology with a gentle touch to ensure you receive the highest standard of care in Ashok Vihar.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-5xl">
        <div className="space-y-24">
          {detailedServices.map((service, idx) => {
            const Icon = service.icon;
            const isEven = idx % 2 === 0;
            
            return (
              <motion.div 
                key={service.id}
                id={service.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.6 }}
                className="scroll-mt-32"
              >
                <div className={`flex flex-col lg:flex-row gap-12 lg:gap-16 items-start ${!isEven ? 'lg:flex-row-reverse' : ''}`}>
                  
                  {/* Visual Column */}
                  <div className="w-full lg:w-1/3 shrink-0">
                    <div className="bg-blue-50 rounded-3xl p-8 flex flex-col items-center justify-center text-center border border-blue-100 h-full relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-blue-100 rounded-full blur-3xl opacity-50 -mr-10 -mt-10"></div>
                      <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center text-blue-600 shadow-md mb-6 relative z-10">
                        <Icon className="w-10 h-10" />
                      </div>
                      <h3 className="text-2xl font-bold text-gray-900 mb-2 relative z-10">{service.title}</h3>
                      <p className="text-blue-600 font-medium relative z-10">{service.shortDesc}</p>
                    </div>
                  </div>

                  {/* Content Column */}
                  <div className="w-full lg:w-2/3 space-y-8">
                    
                    <div>
                      <h4 className="text-xl font-bold text-gray-900 mb-4 pb-2 border-b border-gray-100">The Procedure</h4>
                      <p className="text-gray-600 leading-relaxed text-lg">
                        {service.procedure}
                      </p>
                    </div>

                    <div>
                      <h4 className="text-xl font-bold text-gray-900 mb-4 pb-2 border-b border-gray-100">Key Benefits</h4>
                      <ul className="grid sm:grid-cols-2 gap-3">
                        {service.benefits.map((benefit, i) => (
                          <li key={i} className="flex items-start text-gray-700">
                            <CheckCircle2 className="w-5 h-5 text-emerald-500 mr-2 shrink-0 flex-none" />
                            <span className="text-sm font-medium">{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100">
                      <h4 className="font-bold text-gray-900 mb-2">What to Expect</h4>
                      <p className="text-gray-600">
                        {service.expectations}
                      </p>
                    </div>

                    <div className="pt-4">
                      <Link
                        to={`/book`}
                        className="inline-flex items-center justify-center px-8 py-3 bg-blue-600 text-white font-medium rounded-full hover:bg-blue-700 transition-colors shadow-md group"
                      >
                        Book an Appointment
                        <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                      </Link>
                    </div>

                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </main>
  );
}
