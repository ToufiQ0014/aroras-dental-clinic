import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Clock, User, Phone, Mail, CheckCircle2, AlertCircle, Lock } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';

const services = [
  "Wisdom Tooth Extraction",
  "Root Canal Treatment",
  "Dental Implants",
  "Cavity Treatment & Filling",
  "Deep Cleaning & Gum Care",
  "General Consultation"
];

// Generate some sample times based on the date selected
const generateTimes = () => {
  return [
    "10:00 AM", "11:00 AM", "12:00 PM",
    "02:00 PM", "03:00 PM", "04:30 PM", "06:00 PM"
  ];
};

export default function BookingPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  const [formData, setFormData] = useState({
    service: "",
    date: "",
    time: "",
    firstName: "",
    lastName: "",
    phone: "",
    email: "",
    notes: ""
  });

  const availableTimes = generateTimes();

  useEffect(() => {
    if (user) {
      const parts = user.displayName ? user.displayName.split(' ') : [];
      setFormData(prev => ({
        ...prev,
        firstName: parts[0] || '',
        lastName: parts.slice(1).join(' ') || '',
        email: user.email || ''
      }));
    }
  }, [user]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const nextStep = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setStep(prev => prev + 1);
  };

  const prevStep = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setStep(prev => prev - 1);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    setIsSubmitting(true);
    
    try {
      await addDoc(collection(db, 'bookings'), {
        userId: user.uid,
        service: formData.service,
        date: formData.date,
        time: formData.time,
        firstName: formData.firstName,
        lastName: formData.lastName,
        patientName: `${formData.firstName} ${formData.lastName}`.trim(),
        phone: formData.phone,
        email: formData.email,
        notes: formData.notes,
        status: 'pending',
        createdAt: serverTimestamp()
      });
      
      setIsSubmitting(false);
      setIsSuccess(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error: any) {
      if (error.message && error.message.toLowerCase().includes('permissions')) {
        alert("Could not process booking. Your Firebase Security Rules need to be updated in the Firebase Console to allow authenticated users to write to the 'bookings' collection.");
      } else {
        alert("There was an error processing your booking. Please try again.");
      }
      setIsSubmitting(false);
    }
  };

  if (loading) return null;

  if (!user) {
    return (
      <main className="pt-32 pb-24 bg-slate-50 min-h-screen flex items-center justify-center">
        <div className="container mx-auto px-4 max-w-lg text-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl p-10 shadow-xl border border-gray-100"
          >
            <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Lock className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-3">Sign In Required</h2>
            <p className="text-gray-600 mb-8">
              Please sign in or create an account to book your appointment securely.
            </p>
            <button
              onClick={() => navigate('/auth', { state: { from: location } })}
              className="w-full py-3 px-6 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-full transition-colors shadow-md flex justify-center items-center gap-2"
            >
              Sign In to Continue
            </button>
            <button
              onClick={() => navigate(-1)}
              className="w-full py-3 px-6 mt-3 bg-white border border-gray-200 text-gray-700 hover:bg-gray-50 font-medium rounded-full transition-colors"
            >
              Go Back
            </button>
          </motion.div>
        </div>
      </main>
    );
  }

  return (
    <main className="pt-32 pb-24 bg-slate-50 min-h-screen">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">

        
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Book Your Appointment</h1>
          <p className="text-lg text-gray-600">Select your preferred service and time, and we'll see you soon.</p>
        </div>

        {isSuccess ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-10 md:p-16 text-center shadow-xl border border-gray-100"
          >
            <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Booking Confirmed!</h2>
            <p className="text-lg text-gray-600 mb-8 max-w-lg mx-auto">
              Thank you, {formData.firstName}. Your appointment for {formData.service} has been requested for {formData.date} at {formData.time}. The clinic has been notified and will contact you shortly to confirm.
            </p>
            <button 
              onClick={() => window.location.href = '/'}
              className="inline-flex items-center justify-center px-8 py-3 bg-blue-600 text-white font-medium rounded-full hover:bg-blue-700 transition-colors"
            >
              Return Home
            </button>
          </motion.div>
        ) : (
          <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden">
            {/* Progress Bar */}
            <div className="flex border-b border-gray-100">
              {[1, 2, 3].map((num) => (
                <div 
                  key={num} 
                  className={`flex-1 py-4 text-center font-medium text-sm transition-colors relative ${
                    step === num ? 'text-blue-600' : step > num ? 'text-emerald-600' : 'text-gray-400'
                  }`}
                >
                  <span className="hidden sm:inline">
                    {num === 1 ? '1. Service & Time' : num === 2 ? '2. Your Details' : '3. Confirm'}
                  </span>
                  <span className="sm:hidden">
                    Step {num}
                  </span>
                  {step === num && (
                    <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-1 bg-blue-600" />
                  )}
                </div>
              ))}
            </div>

            <div className="p-6 md:p-10">
              <form onSubmit={handleSubmit}>
                <AnimatePresence mode="wait">
                  
                  {/* STEP 1: Service & Time */}
                  {step === 1 && (
                    <motion.div
                      key="step1"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="space-y-8"
                    >
                      <div>
                        <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                          <CheckCircle2 className="w-5 h-5 text-blue-600" />
                          Select Service
                        </h3>
                        <div className="grid sm:grid-cols-2 gap-4">
                          {services.map(srv => (
                           <label 
                             key={srv} 
                             className={`cursor-pointer rounded-xl border p-4 flex items-center transition-all ${
                               formData.service === srv ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500' : 'border-gray-200 hover:border-blue-300 hover:bg-slate-50'
                             }`}
                           >
                             <input 
                               type="radio" 
                               name="service" 
                               value={srv} 
                               checked={formData.service === srv}
                               onChange={handleInputChange}
                               className="sr-only" 
                             />
                             <div className={`w-5 h-5 rounded-full border flex items-center justify-center mr-3 ${
                               formData.service === srv ? 'border-blue-600' : 'border-gray-300'
                             }`}>
                               {formData.service === srv && <div className="w-2.5 h-2.5 rounded-full bg-blue-600" />}
                             </div>
                             <span className="font-medium text-gray-800">{srv}</span>
                           </label>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                          <Calendar className="w-5 h-5 text-blue-600" />
                          Choose Date
                        </h3>
                        <input
                          type="date"
                          name="date"
                          required
                          value={formData.date}
                          onChange={handleInputChange}
                          min={new Date().toISOString().split('T')[0]}
                          className="w-full sm:w-auto p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-shadow text-gray-800"
                        />
                      </div>

                      {formData.date && (
                        <div>
                          <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                            <Clock className="w-5 h-5 text-blue-600" />
                            Preferred Time
                          </h3>
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                            {availableTimes.map(time => (
                              <label 
                                key={time} 
                                className={`cursor-pointer rounded-xl border p-3 text-center transition-all ${
                                  formData.time === time ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500 text-blue-700 font-semibold' : 'border-gray-200 hover:border-blue-300 hover:bg-slate-50 text-gray-700'
                                }`}
                              >
                                <input 
                                  type="radio" 
                                  name="time" 
                                  value={time} 
                                  checked={formData.time === time}
                                  onChange={handleInputChange}
                                  className="sr-only" 
                                />
                                {time}
                              </label>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="pt-6 border-t border-gray-100 flex justify-end">
                        <button
                          type="button"
                          onClick={() => {
                            if (!formData.service) alert("Please select a service");
                            else if (!formData.date) alert("Please select a date");
                            else if (!formData.time) alert("Please select a time");
                            else nextStep();
                          }}
                          className="px-8 py-3 bg-blue-600 text-white font-medium rounded-full hover:bg-blue-700 transition-colors shadow-md"
                        >
                          Continue to Details
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {/* STEP 2: Details */}
                  {step === 2 && (
                    <motion.div
                      key="step2"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="space-y-6"
                    >
                      <h3 className="text-xl font-bold text-gray-900 mb-2 flex items-center gap-2">
                        <User className="w-5 h-5 text-blue-600" />
                        Patient Details
                      </h3>
                      
                      <div className="grid sm:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">First Name *</label>
                          <input 
                            type="text" 
                            name="firstName"
                            required
                            value={formData.firstName}
                            onChange={handleInputChange}
                            className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-shadow" 
                            placeholder="John"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Last Name *</label>
                          <input 
                            type="text" 
                            name="lastName"
                            required
                            value={formData.lastName}
                            onChange={handleInputChange}
                            className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-shadow" 
                            placeholder="Doe"
                          />
                        </div>
                      </div>

                      <div className="grid sm:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
                          <div className="relative">
                            <Phone className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                            <input 
                              type="tel" 
                              name="phone"
                              required
                              value={formData.phone}
                              onChange={handleInputChange}
                              className="w-full pl-10 p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-shadow" 
                              placeholder="099111 13357"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Email Address (Optional)</label>
                          <div className="relative">
                            <Mail className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                            <input 
                              type="email" 
                              name="email"
                              value={formData.email}
                              onChange={handleInputChange}
                              className="w-full pl-10 p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-shadow" 
                              placeholder="john@example.com"
                            />
                          </div>
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Additional Notes / Symptoms (Optional)</label>
                        <textarea 
                          name="notes"
                          rows={4}
                          value={formData.notes}
                          onChange={handleInputChange}
                          className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-shadow resize-none" 
                          placeholder="Please describe any pain, sensitivity, or specific concerns..."
                        ></textarea>
                      </div>

                      <div className="pt-6 border-t border-gray-100 flex justify-between items-center text-sm">
                        <p className="text-gray-500 flex items-center gap-1">
                          <AlertCircle className="w-4 h-4" /> Your information is secure.
                        </p>
                        <div className="flex gap-3">
                          <button
                            type="button"
                            onClick={prevStep}
                            className="px-6 py-3 text-gray-600 font-medium hover:bg-gray-100 rounded-full transition-colors"
                          >
                            Back
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              if (!formData.firstName || !formData.lastName || !formData.phone) {
                                alert("Please fill in required fields");
                              } else {
                                nextStep();
                              }
                            }}
                            className="px-8 py-3 bg-blue-600 text-white font-medium rounded-full hover:bg-blue-700 transition-colors shadow-md"
                          >
                            Review Details
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {/* STEP 3: Confirm */}
                  {step === 3 && (
                    <motion.div
                      key="step3"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="space-y-6"
                    >
                      <h3 className="text-xl font-bold text-gray-900 mb-6">Review Your Appointment</h3>
                      
                      <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 space-y-4">
                        <div className="flex justify-between items-start pb-4 border-b border-slate-200">
                          <div>
                            <p className="text-sm text-gray-500 mb-1">Service</p>
                            <p className="font-semibold text-gray-900">{formData.service}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm text-gray-500 mb-1">Date & Time</p>
                            <p className="font-semibold text-gray-900">{formData.date}</p>
                            <p className="text-blue-600 font-medium">{formData.time}</p>
                          </div>
                        </div>
                        
                        <div>
                          <p className="text-sm text-gray-500 mb-1">Patient Name</p>
                          <p className="font-medium text-gray-900">{formData.firstName} {formData.lastName}</p>
                        </div>
                        
                        <div>
                          <p className="text-sm text-gray-500 mb-1">Contact Details</p>
                          <p className="font-medium text-gray-900">{formData.phone}</p>
                          {formData.email && <p className="font-medium text-gray-900">{formData.email}</p>}
                        </div>

                        {formData.notes && (
                          <div>
                            <p className="text-sm text-gray-500 mb-1">Notes</p>
                            <p className="text-gray-800 bg-white p-3 rounded-lg text-sm border border-slate-100">{formData.notes}</p>
                          </div>
                        )}
                      </div>

                      <div className="pt-6 border-t border-gray-100 flex justify-between items-center">
                        <button
                          type="button"
                          onClick={prevStep}
                          className="px-6 py-3 text-gray-600 font-medium hover:bg-gray-100 rounded-full transition-colors"
                        >
                          Back
                        </button>
                        <button
                          type="submit"
                          disabled={isSubmitting}
                          className="px-8 py-3 bg-emerald-600 text-white font-medium rounded-full hover:bg-emerald-700 transition-colors shadow-md shadow-emerald-600/20 disabled:opacity-70 disabled:cursor-not-allowed flex items-center gap-2"
                        >
                          {isSubmitting ? (
                            <>
                              <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                              Confirming Booking...
                            </>
                          ) : (
                            "Confirm Appointment"
                          )}
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </form>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
