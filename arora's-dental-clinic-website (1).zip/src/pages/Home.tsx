import React from 'react';
import Hero from '../components/Hero';
import TrustBadges from '../components/TrustBadges';
import ServicesSummary from '../components/Services';
import About from '../components/About';
import Testimonials from '../components/Testimonials';
import CTA from '../components/CTA';

export default function Home() {
  return (
    <main>
      <Hero />
      <TrustBadges />
      <ServicesSummary />
      <About />
      <Testimonials />
      <CTA />
    </main>
  );
}
