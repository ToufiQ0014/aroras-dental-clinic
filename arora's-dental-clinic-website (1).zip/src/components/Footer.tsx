import React from 'react';
import { MapPin, Phone, Globe, Clock, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  const quickLinks = [
    { name: 'Home', href: '/' },
    { name: 'Services', href: '/services' },
    { name: 'About Us', href: '/#about' },
    { name: 'Patient Reviews', href: '/#reviews' },
    { name: 'Contact', href: '/#contact' },
    { name: 'Book Appointment', href: '/book' },
  ];

  return (
    <footer id="contact" className="bg-gray-900 text-gray-300 pt-20 pb-10">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 mb-16">
          
          {/* Brand Col */}
          <div className="lg:col-span-4">
            <Link to="/" className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold text-xl">
                A
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-xl text-white leading-tight">Arora's</span>
                <span className="text-sm font-medium text-blue-400 tracking-wider uppercase leading-tight">Dental Clinic</span>
              </div>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed pr-4">
              Providing advanced, compassionate dental care for patients across Ashok Vihar and Delhi with a commitment to comfort, quality, and lasting oral health.
            </p>
          </div>

          {/* Contact Info Col */}
          <div className="lg:col-span-4">
            <h4 className="text-white font-semibold mb-6 uppercase tracking-wider text-sm">Contact Information</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-4">
                <MapPin className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                <span className="text-sm text-gray-400 leading-relaxed">
                  Res-cum-Clinic, A-10, Near Invitation Restaurant<br />
                  Ashok Vihar II, Phase 2<br />
                  Ashok Vihar, New Delhi, Delhi 110052
                </span>
              </li>
              <li className="flex items-center gap-4">
                <Phone className="w-5 h-5 text-blue-400 shrink-0" />
                <a href="tel:09911113357" className="text-sm hover:text-white transition-colors">099111 13357</a>
              </li>
              <li className="flex items-center gap-4">
                <Globe className="w-5 h-5 text-blue-400 shrink-0" />
                <span className="text-sm">aroradentistindelhi.in</span>
              </li>
              <li className="flex items-center gap-4">
                <Clock className="w-5 h-5 text-blue-400 shrink-0" />
                <span className="text-sm">Open 24 Hours</span>
              </li>
            </ul>
          </div>

          {/* Quick Links Col */}
          <div className="lg:col-span-2">
            <h4 className="text-white font-semibold mb-6 uppercase tracking-wider text-sm">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link to={link.href} className="text-sm text-gray-400 hover:text-blue-400 transition-colors flex items-center gap-1 group">
                    <ChevronRight className="w-4 h-4 text-gray-600 group-hover:text-blue-400 transition-colors" />
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Map Col */}
          <div className="lg:col-span-2">
             <h4 className="text-white font-semibold mb-6 uppercase tracking-wider text-sm">Find Us</h4>
             <div className="w-full h-32 bg-gray-800 rounded-xl overflow-hidden border border-gray-700 relative">
               {/* Place holder for interactive map embed */}
               <div className="absolute inset-0 flex items-center justify-center text-gray-500 bg-gray-800/80 backdrop-blur-sm z-10 pointer-events-none p-4 text-center text-xs">
                 Interactive Map Embedded Here
               </div>
               <img src="https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&q=80&w=400" alt="Map Location Placeholder" className="w-full h-full object-cover opacity-50" />
             </div>
          </div>

        </div>

        <div className="pt-8 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-gray-500">
            &copy; {new Date().getFullYear()} Arora's Dental Clinic. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
