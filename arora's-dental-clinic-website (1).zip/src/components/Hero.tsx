import React from 'react';
import { motion } from 'motion/react';
import { Calendar, PhoneCall, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Hero() {
  const highlights = [
    "Comfortable & Gentle Treatments",
    "Modern Dental Technology",
    "Emergency Dental Care Available",
    "Trusted by Families Across Ashok Vihar"
  ];

  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-slate-50 -z-10" />
      <div className="absolute top-0 right-0 w-1/2 h-full bg-blue-50/50 rounded-l-full blur-3xl -z-10 opacity-50 transform translate-x-1/3" />
      <div className="absolute bottom-0 left-0 w-1/2 h-1/2 bg-sky-100/40 rounded-r-full blur-3xl -z-10 opacity-50 transform -translate-x-1/3" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-2xl"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-100 text-blue-700 font-medium text-sm mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
              </span>
              Accepting New Patients in Ashok Vihar
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
              Gentle Care. <br />
              <span className="text-blue-600">Advanced Dentistry.</span> <br />
              Confident Smiles.
            </h1>
            
            <p className="text-lg sm:text-xl text-gray-600 mb-8 leading-relaxed">
              Premium dental care designed around comfort, precision, and lasting oral health.
              <br className="hidden sm:block" />
              We proudly serve patients across Delhi with modern dental treatments and a welcoming environment.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-10">
              <Link
                to="/book"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-blue-600 text-white font-medium rounded-full hover:bg-blue-700 transition-colors shadow-xl shadow-blue-600/20 text-lg"
              >
                <Calendar className="w-5 h-5" />
                Schedule a Consultation
              </Link>
              <a
                href="tel:09911113357"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white text-gray-900 border border-gray-200 font-medium rounded-full hover:bg-gray-50 transition-colors text-lg shadow-sm"
              >
                <PhoneCall className="w-5 h-5 text-blue-600" />
                Call 099111 13357
              </a>
            </div>

            <div className="grid sm:grid-cols-2 gap-3 lg:gap-4">
              {highlights.map((highlight, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 + (idx * 0.1) }}
                  className="flex items-center gap-2"
                >
                  <CheckCircle2 className="w-5 h-5 text-blue-500 shrink-0" />
                  <span className="text-gray-700 font-medium">{highlight}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative lg:ml-auto"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl aspect-[4/3] lg:aspect-auto lg:h-[600px] w-full max-w-lg mx-auto bg-gray-200">
               {/* Use standard medical image placeholder or abstract geometry */}
               <img 
                 src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&q=80&w=1200" 
                 alt="Modern Dental Clinic" 
                 className="absolute inset-0 w-full h-full object-cover"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
               
               {/* Floating rating badge */}
               <div className="absolute bottom-6 left-6 right-6 bg-white/95 backdrop-blur-sm rounded-2xl p-4 shadow-xl flex items-center gap-4 border border-white/20">
                  <div className="flex -space-x-2">
                     <img className="w-10 h-10 rounded-full border-2 border-white object-cover" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150" alt="Patient" />
                     <img className="w-10 h-10 rounded-full border-2 border-white object-cover" src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=150" alt="Patient" />
                     <img className="w-10 h-10 rounded-full border-2 border-white object-cover" src="https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=150" alt="Patient" />
                  </div>
                  <div>
                    <div className="flex text-yellow-400 text-sm">
                      ★★★★★
                    </div>
                    <div className="text-sm font-semibold text-gray-900">4.9/5 from 93 Reviews</div>
                  </div>
               </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
