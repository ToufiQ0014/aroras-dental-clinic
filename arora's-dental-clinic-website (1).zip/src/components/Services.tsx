import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Sparkles, Activity, ShieldPlus, Drill, ScanHeart } from 'lucide-react';
import { Link } from 'react-router-dom';

const services = [
  {
    icon: Sparkles,
    title: "Wisdom Tooth Extraction",
    subtitle: "Safe and Comfortable Removal",
    id: "wisdom-tooth",
    points: [
      "Comprehensive evaluation before treatment",
      "Gentle extraction techniques",
      "Relief from pain and swelling",
      "Post-treatment healing guidance"
    ]
  },
  {
    icon: Activity,
    title: "Root Canal Treatment",
    subtitle: "Save Natural Teeth, Eliminate Pain",
    id: "root-canal",
    points: [
      "Removes internal tooth infection",
      "Advanced techniques for comfort",
      "Preserves natural tooth structure",
      "Restores normal chewing function"
    ]
  },
  {
    icon: ShieldPlus,
    title: "Dental Implants",
    subtitle: "Permanent Solutions for Missing Teeth",
    id: "dental-implants",
    points: [
      "Natural-looking tooth replacement",
      "Improved chewing and confidence",
      "Long-lasting and durable",
      "Helps maintain jawbone health"
    ]
  },
  {
    icon: Drill,
    title: "Cavity Treatment",
    subtitle: "Protect Teeth Early",
    id: "cavity-treatment",
    points: [
      "Early detection of tooth decay",
      "Tooth-colored natural fillings",
      "Restores strength and function",
      "Minimally invasive approach"
    ]
  },
  {
    icon: ScanHeart,
    title: "Deep Cleaning & Care",
    subtitle: "Healthier Gums, Stronger Smile",
    id: "deep-cleaning",
    points: [
      "Professional plaque & tartar removal",
      "Scaling and Root Planing",
      "Reduces gum inflammation",
      "Freshens breath & supports health"
    ]
  }
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-slate-50 relative">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-blue-600 font-semibold tracking-wider uppercase text-sm mb-3">Our Services</h2>
            <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Comprehensive Dental Care <br className="hidden sm:block"/>Under One Roof</h3>
            <p className="text-gray-600 text-lg">
              From routine cleanings to advanced surgical procedures, our clinic offers a full spectrum of dental treatments tailored to your oral health needs.
            </p>
          </motion.div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, idx) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100 hover:shadow-xl hover:border-blue-100 transition-all flex flex-col h-full group"
              >
                <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  <Icon className="w-7 h-7" />
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-2">{service.title}</h4>
                <p className="text-sm text-blue-600 font-medium mb-6">{service.subtitle}</p>
                
                <ul className="space-y-3 mb-8 flex-grow">
                  {service.points.map((point, pIdx) => (
                    <li key={pIdx} className="flex items-start text-gray-600 text-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-400 mr-3 mt-2 shrink-0"></span>
                      {point}
                    </li>
                  ))}
                </ul>

                <Link to={`/services#${service.id}`} className="inline-flex items-center text-blue-600 font-semibold text-sm group/link mt-auto pt-4 border-t border-gray-50">
                  Learn More
                  <ArrowRight className="w-4 h-4 ml-2 group-hover/link:translate-x-1 transition-transform" />
                </Link>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
