import React from 'react';
import { motion } from 'motion/react';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: "Akhil",
    rating: 5,
    text: "Arora's Dental Clinic offers excellent care and affordable treatment. The Dental Surgeon is very professional and genuinely cares about patients' comfort. My wisdom tooth extraction was a comfortable experience. Highly recommended dental clinic in Ashok Vihar."
  },
  {
    name: "Vishal",
    rating: 5,
    text: "I had a large cavity and jaw pain. The dentist was professional and gentle, and the treatment went smoothly. The clinic is clean and well organized. I'm very satisfied with the care received."
  },
  {
    name: "Raj",
    rating: 5,
    text: "Arora's Dental Clinic is clean, well-equipped, and the dentist is extremely skilled. The entire team helped me feel relaxed during my root canal treatment. Best dental clinic in Ashok Vihar."
  }
];

export default function Testimonials() {
  return (
    <section id="reviews" className="py-24 bg-blue-600 text-white relative">
      {/* Abstract background pattern/gradient */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
             <h2 className="text-blue-200 font-semibold tracking-wider uppercase text-sm mb-3">Testimonials</h2>
             <h3 className="text-3xl md:text-4xl font-bold mb-6">What Our Patients Are Saying</h3>
          </motion.div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((review, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.15 }}
              className="bg-white/10 backdrop-blur-sm border border-white/20 p-8 rounded-3xl relative"
            >
              <Quote className="absolute top-6 right-6 w-8 h-8 text-white/20" />
              
              <div className="flex gap-1 mb-4">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              
              <p className="text-blue-50 leading-relaxed mb-6 font-medium italic">
                "{review.text}"
              </p>
              
              <div className="flex items-center gap-3 mt-auto">
                <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center font-bold text-lg">
                  {review.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-semibold text-white">{review.name}</h4>
                  <p className="text-sm text-blue-200">Verified Patient</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
