import React from 'react';
import { Star, Clock, Stethoscope, Heart, Rainbow, HeartHandshake } from 'lucide-react';
import { motion } from 'motion/react';

const badges = [
  {
    icon: Star,
    title: "4.9/5 Google Rating",
    desc: "Based on 93 Verified Reviews",
    color: "text-amber-500",
    bg: "bg-amber-50"
  },
  {
    icon: Clock,
    title: "Open 24 Hours",
    desc: "Emergency Dental Support Available",
    color: "text-blue-600",
    bg: "bg-blue-50"
  },
  {
    icon: Stethoscope,
    title: "Comprehensive Care",
    desc: "Preventive, Restorative & Surgical",
    color: "text-emerald-600",
    bg: "bg-emerald-50"
  },
  {
    icon: Heart,
    title: "Patient Comfort Focused",
    desc: "Gentle & Anxiety-Free Approach",
    color: "text-rose-500",
    bg: "bg-rose-50"
  },
  {
    icon: Rainbow,
    title: "Inclusive Care",
    desc: "LGBTQ+ Friendly Environment",
    color: "text-purple-500",
    bg: "bg-purple-50"
  },
  {
    icon: HeartHandshake,
    title: "Women-Owned Clinic",
    desc: "Trusted Community Provider",
    color: "text-indigo-500",
    bg: "bg-indigo-50"
  }
];

export default function TrustBadges() {
  return (
    <section className="py-16 bg-white border-y border-gray-100">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {badges.map((badge, index) => {
            const Icon = badge.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="flex items-start gap-4 p-6 rounded-2xl border border-gray-100 bg-white hover:shadow-lg hover:border-blue-100 transition-all group"
              >
                <div className={`p-4 rounded-xl ${badge.bg} ${badge.color} group-hover:scale-110 transition-transform`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">{badge.title}</h3>
                  <p className="text-sm text-gray-500">{badge.desc}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
