import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';

const benefits = [
  "Modern and well-equipped treatment rooms",
  "Patient-centered approach focused on comfort",
  "Transparent treatment recommendations",
  "High standards of cleanliness and hygiene",
  "Emergency dental care availability",
  "Trusted by local families and professionals"
];

export default function About() {
  return (
    <section id="about" className="py-24 bg-white relative overflow-hidden">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="grid grid-cols-2 gap-4">
              <img 
                src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&q=80&w=800" 
                alt="Dental Tools" 
                className="rounded-3xl w-full h-64 object-cover mt-8"
              />
              <img 
                src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&q=80&w=800" 
                alt="Dental Clinic Room" 
                className="rounded-3xl w-full h-80 object-cover"
              />
            </div>
            
            {/* Experience badge */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white p-6 rounded-2xl shadow-xl border border-gray-100 flex flex-col items-center justify-center text-center">
              <span className="text-4xl font-bold text-blue-600 mb-1">Top</span>
              <span className="text-sm font-semibold text-gray-800 uppercase tracking-wider">Rated Care</span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h2 className="text-blue-600 font-semibold tracking-wider uppercase text-sm mb-3">About The Clinic</h2>
            <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Trusted Dental Care <br/>in Ashok Vihar</h3>
            
            <div className="space-y-4 text-gray-600 text-lg mb-8">
              <p>
                At Arora's Dental Clinic, dental treatment is built around a simple philosophy: exceptional clinical care should always be paired with compassion, comfort, and clear communication.
              </p>
              <p>
                Located in Ashok Vihar, Delhi, the clinic has earned a reputation for delivering high-quality dental care in a clean, welcoming, and patient-focused environment. From routine dental checkups to advanced restorative procedures, each treatment plan is tailored to individual needs.
              </p>
              <p>
                The clinic combines modern dental technology with a gentle approach that helps patients feel relaxed throughout treatment. 
              </p>
            </div>

            <div className="bg-slate-50 rounded-2xl p-6 md:p-8 border border-gray-100">
              <h4 className="font-bold text-gray-900 mb-4 text-lg">Why Patients Choose Us</h4>
              <ul className="grid sm:grid-cols-2 gap-3">
                {benefits.map((benefit, idx) => (
                  <li key={idx} className="flex items-start text-sm text-gray-700 font-medium">
                    <CheckCircle2 className="w-5 h-5 text-blue-500 mr-3 shrink-0 flex-none" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
            
          </motion.div>
        </div>
      </div>
    </section>
  );
}
