import React from 'react';
import { motion } from 'motion/react';
import { Calendar, PhoneCall } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function CTA() {
  return (
    <section className="py-20 relative overflow-hidden bg-slate-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="bg-white rounded-[2.5rem] p-8 md:p-16 text-center shadow-2xl border border-gray-100 max-w-5xl mx-auto relative overflow-hidden"
        >
          {/* Abstract background blobs */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-50 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 opacity-60"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-sky-50 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2 opacity-60"></div>
          
          <div className="relative z-10">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6 tracking-tight">
              Ready for a Healthier,<br className="hidden md:block" /> More Confident Smile?
            </h2>
            <p className="text-lg md:text-xl text-gray-600 mb-10 max-w-2xl mx-auto">
              Schedule a consultation with the experienced team at Arora's Dental Clinic and receive personalized dental care in a comfortable environment.
            </p>
            
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link
                to="/book"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-blue-600 text-white font-semibold rounded-full hover:bg-blue-700 transition-colors shadow-xl shadow-blue-600/20 text-lg"
              >
                <Calendar className="w-5 h-5" />
                Schedule a Consultation
              </Link>
              <a
                href="tel:09911113357"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white text-gray-900 border border-gray-200 font-semibold rounded-full hover:bg-gray-50 transition-colors text-lg shadow-sm"
              >
                <PhoneCall className="w-5 h-5 text-blue-600" />
                Call 099111 13357
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
