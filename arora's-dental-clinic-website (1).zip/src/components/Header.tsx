import React, { useState, useEffect } from 'react';
import { Menu, X, PhoneCall, UserCircle, LogOut, CalendarDays } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, isAdmin, logout } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLogout = async () => {
    await logout();
    navigate('/');
    setMobileMenuOpen(false);
  };

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'Services', href: '/services' },
    { name: 'About Us', href: '/#about' },
    { name: 'Patient Reviews', href: '/#reviews' },
    { name: 'Contact', href: '/#contact' },
  ];

  return (
    <header
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-3' : 'bg-white/90 backdrop-blur-md py-5'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center gap-4">
          {/* Logo */}
          <div className="flex-shrink-0">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-xl">
                A
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-xl text-gray-900 leading-tight">Arora's</span>
                <span className="text-sm font-medium text-blue-600 tracking-wider uppercase leading-tight">Dental Clinic</span>
              </div>
            </Link>
          </div>

          {/* Desktop Nav */}
          <div className="hidden lg:flex flex-1 items-center justify-center lg:px-2">
            <nav className="flex items-center gap-4 xl:gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.href}
                  className="text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors whitespace-nowrap"
                >
                  {link.name}
                </Link>
              ))}
            </nav>
          </div>

          {/* User Auth & CTA Button */}
          <div className="hidden lg:flex flex-shrink-0 items-center justify-end gap-3">
            {user ? (
              <div className="flex items-center bg-gray-50/80 border border-gray-200 rounded-full p-1 shadow-sm shrink-0">
                {isAdmin && (
                  <Link to="/admin" className="text-xs font-bold text-red-600 hover:text-red-700 pr-3 pl-3 py-1 flex items-center bg-red-50 rounded-full mr-1 transition-colors">
                    Admin
                  </Link>
                )}
                <Link to="/my-bookings" className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-white rounded-full transition-colors hidden xl:flex items-center gap-2 px-3"
                  title="My Bookings"
                >
                  <CalendarDays className="w-4 h-4" />
                  <span className="text-xs font-semibold">Bookings</span>
                </Link>
                <Link to="/my-bookings" className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-white rounded-full transition-colors xl:hidden mx-1"
                  title="My Bookings"
                >
                  <CalendarDays className="w-4 h-4" />
                </Link>
                
                <div className="w-px h-4 bg-gray-300 mx-1"></div>
                
                <div className="flex items-center pl-2 pr-1 gap-2">
                  <span className="text-sm font-medium text-gray-700 max-w-[80px] xl:max-w-[120px] truncate" title={user.displayName || user.email || ''}>
                    {user.displayName?.split(' ')[0] || user.email?.split('@')[0]}
                  </span>
                  <button
                    onClick={handleLogout}
                    className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-white rounded-full transition-colors"
                    title="Sign Out"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : (
              <Link
                to="/auth"
                className="text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors px-3 font-semibold whitespace-nowrap flex items-center gap-2"
              >
                <UserCircle className="w-5 h-5" />
                Sign In
              </Link>
            )}

            <Link
              to="/book"
              className="inline-flex items-center justify-center px-4 py-2 xl:px-6 xl:py-2.5 bg-blue-600 text-white text-sm xl:text-base font-medium rounded-full hover:bg-blue-700 transition-colors shadow-md shadow-blue-600/20 whitespace-nowrap shrink-0"
            >
              Book<span className="hidden xl:inline">&nbsp;Appointment</span>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-gray-600 hover:text-blue-600 focus:outline-none"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-white border-t border-gray-100"
          >
            <div className="px-4 pt-2 pb-6 space-y-1 shadow-inner">
              {user && (
                <div className="px-3 py-4 flex flex-col border-b border-gray-100 mb-2 gap-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <UserCircle className="w-8 h-8 text-blue-600" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">{user.displayName || user.email?.split('@')[0]}</p>
                        <p className="text-xs text-gray-500">{user.email}</p>
                      </div>
                    </div>
                    <button
                      onClick={handleLogout}
                      className="p-2 text-gray-500 hover:text-red-600 rounded-full bg-gray-50"
                    >
                      <LogOut className="w-5 h-5" />
                    </button>
                  </div>
                  {isAdmin && (
                    <Link
                      to="/admin"
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-3 text-sm font-bold text-red-600 hover:text-red-700 transition-colors bg-red-50 p-3 rounded-xl"
                    >
                      Admin Portal
                    </Link>
                  )}
                  <Link
                    to="/my-bookings"
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center gap-3 text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors bg-gray-50 p-3 rounded-xl"
                  >
                    <CalendarDays className="w-5 h-5 text-blue-600" />
                    My Bookings
                  </Link>
                </div>
              )}

              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="block px-3 py-4 text-base font-medium text-gray-700 hover:bg-blue-50 hover:text-blue-600 rounded-lg transition-colors"
                >
                  {link.name}
                </Link>
              ))}

              {!user && (
                <Link
                  to="/auth"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-4 text-base font-medium text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                >
                   <UserCircle className="w-5 h-5" />
                  Sign In / Register
                </Link>
              )}

              <div className="px-3 pt-4">
                <Link
                  to="/book"
                  onClick={() => setMobileMenuOpen(false)}
                  className="w-full flex items-center justify-center px-6 py-3 bg-blue-600 text-white font-medium rounded-full hover:bg-blue-700 transition-colors shadow-md"
                >
                  Book Appointment
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
