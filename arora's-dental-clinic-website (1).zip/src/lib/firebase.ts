import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCWwXNbi5Y7sYt7iBIJn_X5gkYmkjpKP9Q",
  authDomain: "arora-s-dental-clinic.firebaseapp.com",
  projectId: "arora-s-dental-clinic",
  storageBucket: "arora-s-dental-clinic.firebasestorage.app",
  messagingSenderId: "2344877592",
  appId: "1:2344877592:web:717c86c878d604d430cd6d"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
